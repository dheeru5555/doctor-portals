module.exports = {
  redTheme: {
    palette: {
      primary: {
        light: '#eb2330',
        main: '#eb2330',
        dark: '#eb2330',
        contrastText: '#fff',
      },
      secondary: {
        light: '#eb2330',
        main: '#eb2330',
        dark: '#eb2330',
        contrastText: '#fff',
      }
    },
  }
};
